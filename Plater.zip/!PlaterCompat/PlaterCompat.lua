-- Functions added in 8.0 that the Legion 7.3.5 client lacks.
-- Never modify Blizzard globals or mixins here: that taints Blizzard's secure nameplate code.

PlaterCompat = {}

-- PixelUtil: 8.0 snaps sizes/offsets to whole screen pixels. Blizzard's 7.3.5 code never uses it.
-- ponytail: plain pass-through, no pixel snapping; edges may be ~1px soft at some UI scales.
if not PixelUtil then
	PixelUtil = {
		SetPoint = function(region, point, relativeTo, relativePoint, x, y)
			region:SetPoint(point, relativeTo, relativePoint, x or 0, y or 0)
		end,
		SetWidth = function(region, width) region:SetWidth(width) end,
		SetHeight = function(region, height) region:SetHeight(height) end,
		SetSize = function(region, width, height) region:SetSize(width, height) end,
		SetStatusBarValue = function(bar, value) bar:SetValue(value) end,
	}
end

-- Aura functions: Legion returns an extra 'rank' as the 2nd value; 8.0 removed it.
-- Use as file-local replacements in the ported files, never as globals.
local function DropRank(name, _, ...)
	return name, ...
end
function PlaterCompat.UnitAura(...) return DropRank(UnitAura(...)) end
function PlaterCompat.UnitBuff(...) return DropRank(UnitBuff(...)) end
function PlaterCompat.UnitDebuff(...) return DropRank(UnitDebuff(...)) end

-- Cast info: Legion returns an extra 'subText' as the 2nd value; 8.0 removed it.
function PlaterCompat.UnitCastingInfo(...) return DropRank(UnitCastingInfo(...)) end
function PlaterCompat.UnitChannelInfo(...) return DropRank(UnitChannelInfo(...)) end

-- Nameplate border: 8.0 added SetBorderSizes/UpdateSizes to the border template.
-- Mix into Plater's own border frames only: Mixin(border, PlaterCompat.BorderMixin)
-- Legion's border is 3 soft layers of 4 edges (left, right, bottom, top), 2 / 1.5 / 1 px thick.
local LAYER_SCALE = { 1, 0.75, 0.5 }

PlaterCompat.BorderMixin = {
	SetBorderSizes = function(self, size)
		self.compatBorderSize = size
	end,

	UpdateSizes = function(self)
		local size = self.compatBorderSize
		if not size or not self.Textures then return end
		for i, texture in ipairs(self.Textures) do
			local s = size * (LAYER_SCALE[math.floor((i - 1) / 4) + 1] or 0.5)
			if (i - 1) % 4 < 2 then
				-- left/right: set width, stretch past the corners by the new thickness
				texture:SetWidth(s)
				for p = 1, texture:GetNumPoints() do
					local point, rel, relPoint, x, y = texture:GetPoint(p)
					if y ~= 0 then texture:SetPoint(point, rel, relPoint, x, y > 0 and s or -s) end
				end
			else
				texture:SetHeight(s)
			end
		end
	end,
}
